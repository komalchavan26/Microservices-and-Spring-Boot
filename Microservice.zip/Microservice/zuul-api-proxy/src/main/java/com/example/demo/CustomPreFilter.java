package com.example.demo;

import org.springframework.cloud.netflix.zuul.filters.support.FilterConstants;
import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

import lombok.extern.slf4j.Slf4j;

@Slf4j

public class CustomPreFilter extends ZuulFilter {

	@Override
	public boolean shouldFilter() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public Object run() throws ZuulException {
		// TODO Auto-generated method stub
		log.info("pre filter called");
		log.info("Pre Filter Run Method Called");
		
		RequestContext ctx = RequestContext.getCurrentContext();
		
		if(ctx.getRequest().getRequestURI().contains("/api/v1")) {
	          ctx.setResponseStatusCode(300);
	          ctx.setResponseBody("New Version v2 is available Use It");
	          ctx.setSendZuulResponse(false);
		}
		return null;
	}

	@Override
	public String filterType() {
		// TODO Auto-generated method stub
		return FilterConstants.PRE_TYPE;
	}

	@Override
	public int filterOrder() {
		// TODO Auto-generated method stub
		return 1;
	}

}
