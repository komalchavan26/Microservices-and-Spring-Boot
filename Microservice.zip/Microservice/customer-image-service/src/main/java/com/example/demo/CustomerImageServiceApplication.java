package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.example.demo.entity.CustomerImage;

@SpringBootApplication
public class CustomerImageServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerImageServiceApplication.class, args);
	}
	@Bean
	public CustomerImage specific() {
		return new CustomerImage(101,"komal","/images/komal.jpg","customer");
	}
//	@Bean
//	public CustomerImage standBy() {
//		return new CustomerImage(102,"guest","/images/komal.jpg","default");
//	}
	
}
