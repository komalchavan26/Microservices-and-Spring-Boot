package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.entity.CustomerImage;
import com.netflix.discovery.shared.Application;

@RestController
@CrossOrigin(origins="*")
public class CustomerImageController {

	@Autowired
	@Qualifier("specific")
	private CustomerImage specific;
//	
//	@Autowired
//	@Qualifier("standBy")
//	private CustomerImage standBy;
	
	@GetMapping(path="api/v1/images/{id}" ,produces ="application/json")
	public CustomerImage fetchImage(@PathVariable("id") int id) throws InterruptedException {
		
		//CustomerImage image=standBy;
		CustomerImage image=null;
		
		if(id<10) {
			image=specific;
		}else {
			Thread.sleep(6000);
		}
		return image;
	}
}
