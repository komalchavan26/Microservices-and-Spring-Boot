package com.example.demo;

import com.example.demo.ifaces.CustomerImageClient;

@Component
public class HystrixClientFallback implements CustomerImageClient {

	@Override
	public String getImageById(int id) {
		// TODO Auto-generated method stub
		return new String("{0,guest,/images/customer,dafault image}");
	}

}
