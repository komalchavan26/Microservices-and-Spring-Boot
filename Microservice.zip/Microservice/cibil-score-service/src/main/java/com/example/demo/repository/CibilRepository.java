package com.example.demo.repository;

import org.springframework.stereotype.Repository;
import com.example.demo.entity.CibilScore;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface CibilRepository extends JpaRepository<CibilScore, Integer>{

}
